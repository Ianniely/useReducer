export const motivationalQuotes = [
    "O sucesso é a soma de pequenos esforços repetidos dia após dia.",
    "A persistência é o caminho do êxito.",
    "Você é mais forte do que imagina.",
    "Acredite que você pode, assim você já está no meio do caminho.",
    "Não pare quando estiver cansado. Pare quando tiver terminado.",
    "A única maneira de fazer um excelente trabalho é amar o que você faz."
  ];
  